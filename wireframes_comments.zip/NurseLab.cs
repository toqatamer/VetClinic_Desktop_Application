﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WireFrames
{
    internal class NurseLab
    {
   
        public string PetID { get; set; }
        public string ChooseTime { get; set; }

    }
}
