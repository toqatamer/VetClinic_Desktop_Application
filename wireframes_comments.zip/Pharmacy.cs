﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WireFrames
{
    internal class Pharmacy
    {
        public string AvailableDrugs { get; set; }
        public string AddDrug { get; set; } 
 
        public string Vaccinces { get; set; }
        public string AddVaccines { get; set; }
    }
}
