﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WireFrames
{
    internal class NurseAddPatient
    { 
        public string PetName { get; set; }
        public string PetType { get; set; }
        public string PetGender { get; set; }
        public string Allergies { get; set; }
        public string PrevDiseases { get; set; }
        public string Weight { get; set; }
        public string Height { get; set; }
        public string Age { get; set; }
    }
}
