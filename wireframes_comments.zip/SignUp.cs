﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WireFrames
{
    internal class PatientSignUp
    {
        public string PatientName { get; set; }
        public string PatientNationalID { get; set; }
        public string PatientPassword { get; set; }
        public string PatientPhone { get; set; }
    }
}
