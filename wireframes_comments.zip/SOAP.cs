﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WireFrames
{
    internal class SOAP
    {
        public string PetID { get; set; }
        public string Subjective { get; set;}
        public string Objective { get; set;}
        public string Assessment { get; set;}
        public string Plan__ { get; set;}
        public string Date { get; set;}
    }
}
