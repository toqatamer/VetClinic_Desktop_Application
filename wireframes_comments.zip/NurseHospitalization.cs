﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WireFrames
{
    internal class NurseHospitalization
    {
        public string PetID { get; set; }
        public string from__ { get; set; }
        public string to__ { get; set; }  
    }
}
